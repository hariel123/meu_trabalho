// Jogo "Descubra o número"

let numeroAleatorio = Math.floor(Math.random() * 100) + 1; // Gera um número aleatório entre 1 e 100
let tentativas = 0;

function tentarNumero() {
  let palpite = parseInt(prompt("Digite um número entre 1 e 100:"));
  tentativas++;

  if (palpite === numeroAleatorio) {
    alert(`Parabéns! Você acertou o número ${numeroAleatorio} em ${tentativas} tentativas.`);
  } else if (palpite < numeroAleatorio) {
    alert("O número é maior. Tente novamente.");
    tentarNumero(); // Chama a função novamente para mais tentativas
  } else if (palpite > numeroAleatorio) {
    alert("O número é menor. Tente novamente.");
    tentarNumero(); // Chama a função novamente para mais tentativas
  }
}

tentarNumero(); // In

